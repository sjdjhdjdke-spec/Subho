package Shinigami.com;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private EditText etKey;
    private Button btnLogin;
    private DatabaseReference keysRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etKey = findViewById(R.id.etKey);
        btnLogin = findViewById(R.id.btnLogin);

        FirebaseDatabase database = FirebaseDatabase.getInstance(
            "https://shinigami-9df73-default-rtdb.firebaseio.com/"
        );
        keysRef = database.getReference("keys");

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String key = etKey.getText().toString().trim();
                if (key.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter license key", Toast.LENGTH_SHORT).show();
                    return;
                }
                btnLogin.setEnabled(false);
                keysRef.child(key).child("status").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        btnLogin.setEnabled(true);
                        String status = snapshot.getValue(String.class);
                        if ("active".equalsIgnoreCase(status)) {
                            Toast.makeText(MainActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(MainActivity.this, DashboardActivity.class));
                        } else if (snapshot.exists()) {
                            Toast.makeText(MainActivity.this, "Key is INACTIVE by Admin!", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Invalid Key!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        btnLogin.setEnabled(true);
                        Toast.makeText(MainActivity.this, "Database Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }
}
