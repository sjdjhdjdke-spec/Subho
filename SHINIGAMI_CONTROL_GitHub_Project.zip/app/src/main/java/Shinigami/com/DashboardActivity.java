package Shinigami.com;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Button btnOpenCarrom = findViewById(R.id.btnOpenCarrom);
        btnOpenCarrom.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.miniclip.carrompool");
            if (launch != null) {
                startActivity(launch);
            } else {
                Toast.makeText(this, "Carrom Disc Pool is not installed!", Toast.LENGTH_LONG).show();
            }
        });
    }
}
