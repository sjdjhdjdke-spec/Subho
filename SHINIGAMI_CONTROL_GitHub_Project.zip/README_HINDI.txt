SHINIGAMI CONTROL - GitHub Actions APK Project

इस ZIP में फाइलें सही अलग-अलग जगहों पर रखी गई हैं। पहले भेजे गए टेक्स्ट में कई फाइलें आपस में जुड़ गई थीं; उन्हें अलग किया गया है।

APK बनाने के लिए:
1. GitHub पर SHINIGAMI-CONTROL नाम का repository बनाएं।
2. इस ZIP की सामग्री repository के root में upload करें (ZIP को repository में ZIP के रूप में नहीं, Extract की हुई files के रूप में रखें)।
3. app/google-services.json में आपका Firebase Android configuration शामिल है।
4. Repository में Actions tab खोलें और "Build Android APK" workflow चलाएं।
5. सफल run के Artifacts से SHINIGAMI-CONTROL-APK डाउनलोड करें। उसमें app-debug.apk होगा।

इस starter में:
- Firebase Realtime Database के keys/<license-key>/status को पढ़कर active/inactive check
- Carrom Disc Pool लॉन्च बटन
- GitHub Actions APK build workflow

महत्वपूर्ण सुरक्षा:
- firebase-sample-data.json केवल उदाहरण है। इसे Firebase Console में स्वयं जोड़ना होगा; इसे अपने-आप डेटाबेस में अपलोड नहीं किया गया।
- Firebase Realtime Database Rules को सार्वजनिक read/write न रखें।
- मौजूदा Android ऐप सीधे डेटાબेस से key status पढ़ता है। बिना Firebase Authentication या सुरक्षित server-side verification के इसे production-grade सुरक्षा न मानें।
- अभी Admin Panel, key creation, update notice, APK release signing और Storage upload flow शामिल नहीं हैं।
- APK अभी compile या device पर test नहीं हुआ है।
