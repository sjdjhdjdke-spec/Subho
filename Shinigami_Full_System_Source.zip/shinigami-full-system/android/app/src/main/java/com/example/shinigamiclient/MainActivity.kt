package com.example.shinigamiclient

import android.app.Activity
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    // Replace with your deployed HTTPS API URL; keep trailing slash.
    private val BASE_URL = "https://YOUR-SERVER-DOMAIN/"
    private val bg = Color.rgb(9,9,13)
    private val red = Color.rgb(231,45,85)
    private lateinit var status: TextView
    private lateinit var keyInput: EditText
    private val deviceId by lazy { Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device" }

    private fun box(color:Int, radius:Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=radius.toFloat() }
    private fun label(s:String,size:Float,color:Int,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold) setTypeface(typeface,Typeface.BOLD); setPadding(0,8,0,8)
    }
    private fun request(path:String, body:JSONObject):JSONObject {
        val c=URL(BASE_URL+path).openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.connectTimeout=10000; c.readTimeout=10000
        c.doOutput=true; c.setRequestProperty("Content-Type","application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream
        val result=stream.bufferedReader().use{it.readText()}
        c.disconnect()
        return JSONObject(result)
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState); window.statusBarColor=bg; window.navigationBarColor=bg
        val root=LinearLayout(this).apply { orientation=1; setPadding(36,32,36,24); setBackgroundColor(bg) }
        root.addView(label("♨  SHINIGAMI",30f,red,true))
        root.addView(label("GAMING CONTROL CLIENT",12f,Color.LTGRAY,true))
        val banner=LinearLayout(this).apply { orientation=1; setPadding(24,22,24,22); background=box(Color.rgb(65,12,30),22) }
        banner.addView(label("AIM. STRIKE. WIN.",28f,Color.WHITE,true))
        banner.addView(label("Your access, controlled securely.",14f,Color.LTGRAY))
        root.addView(banner)
        root.addView(label("Activate your license",21f,Color.WHITE,true))
        keyInput=EditText(this).apply { hint="Enter license key"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(); background=box(Color.rgb(35,35,43),14); setPadding(18,12,18,12) }
        root.addView(keyInput)
        val activate=Button(this).apply { text="Activate"; setTextColor(Color.WHITE); background=box(red,14) }
        root.addView(activate)
        status=label("Status: Not activated",14f,Color.LTGRAY)
        root.addView(status)
        val check=Button(this).apply { text="Check access"; setTextColor(Color.WHITE); background=box(Color.rgb(65,35,48),14) }
        root.addView(check)
        root.addView(label("Demo client • Connects to your admin-managed license server",12f,Color.GRAY))
        activate.setOnClickListener { runApi("license/activate") }
        check.setOnClickListener { runApi("license/check") }
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun runApi(endpoint:String) {
        val key=keyInput.text.toString().trim()
        if(key.isEmpty()){ status.text="Enter your license key first"; return }
        status.text="Checking server…"
        thread {
            try {
                val body=JSONObject().put("key",key).put("deviceId",deviceId).put("deviceName",android.os.Build.MODEL)
                val response=request(endpoint,body)
                runOnUiThread {
                    val expiry=response.optString("expires_at","")
                    status.text=if(response.optString("status")=="active") "✓ ACTIVE — Expires: $expiry" else "Status: ${response.optString("status","unknown")}"
                    status.setTextColor(if(response.optString("status")=="active") Color.rgb(100,220,140) else red)
                }
            } catch(e:Exception) { runOnUiThread { status.text="Connection failed: ${e.message}" } }
        }
    }
}
