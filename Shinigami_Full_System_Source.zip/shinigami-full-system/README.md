# Shinigami Control — starter full-stack system

This bundle contains:
- `server/`: Node.js + Express + SQLite API, admin login, user/license management, expiry and ban enforcement.
- `admin/`: responsive admin dashboard served by the API.
- `android/`: minimal native Android (Kotlin) client that activates with a license key and checks access against the server.

## Important
This is a runnable starter/MVP, not a hosted service and not a signed APK. You must deploy the server to a public HTTPS host, configure secrets, then build/sign the Android app. No hosting account, domain, signing key, or credentials were provided, so those cannot be created on your behalf here.

## 1) Run the backend locally
Requirements: Node.js 20+.

```bash
cd server
cp .env.example .env
npm install
npm start
```

Open `http://localhost:3000`. Default local admin:
- username: `admin`
- password: `ChangeMe!2026`

Change `ADMIN_PASSWORD` and `JWT_SECRET` in `.env` before exposing this server to the internet. The first start creates the SQLite database and default admin.

## 2) Admin dashboard
Open `http://localhost:3000` and sign in. You can:
- view total, active, expired and banned users
- create license keys with expiry days and device limits
- inspect users, ban/unban, extend expiry, delete records
- view recent activation/check activity

“Active” in this MVP means a license is currently valid and not banned; it is not a live count of people currently looking at the app. The dashboard shows last-seen/check time separately.

## 3) Android app
Open `android/` in Android Studio. Set `BASE_URL` in `MainActivity.kt` to your deployed HTTPS API URL (include trailing slash), then Build > Build APK(s).
The app accepts a license key and device label, activates it, and checks status with the backend. It is a demo client; add your real game feature screens and your own branding before release.

## 4) Deploy
Deploy `server/` to a Node host with persistent disk storage (SQLite database file is stored at `server/data.sqlite`). Use HTTPS. Set:
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD` (strong unique password)
- `JWT_SECRET` (long random secret)
- `PORT` (host-provided port)

Do not use the sample credentials in production. Back up `data.sqlite`. Restrict admin access and add rate limiting/monitoring before public launch.

## API
- `POST /api/admin/login` `{username,password}`
- `GET /api/admin/stats` (Bearer admin token)
- `GET /api/admin/licenses`
- `POST /api/admin/licenses` `{days,deviceLimit,note}`
- `PATCH /api/admin/licenses/:id` `{banned,extendDays}`
- `DELETE /api/admin/licenses/:id`
- `POST /api/license/activate` `{key,deviceId,deviceName}`
- `POST /api/license/check` `{key,deviceId}`

The server enforces expiry, ban state, and per-license device limit. License keys are stored as SHA-256 hashes, not plaintext.
