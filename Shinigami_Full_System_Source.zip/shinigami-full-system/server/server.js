require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-this-secret";
if (process.env.NODE_ENV === "production" && (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32)) {
  throw new Error("Set a strong JWT_SECRET (32+ chars) in production");
}
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors());
app.use(express.json({limit:"32kb"}));
app.use(express.static(path.join(__dirname, "../admin")));

const db = new Database(path.join(__dirname, "data.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS licenses(
 id INTEGER PRIMARY KEY, key_hash TEXT UNIQUE NOT NULL, key_hint TEXT NOT NULL,
 created_at TEXT NOT NULL, expires_at TEXT NOT NULL, banned INTEGER NOT NULL DEFAULT 0,
 device_limit INTEGER NOT NULL DEFAULT 1, note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS devices(
 id INTEGER PRIMARY KEY, license_id INTEGER NOT NULL, device_id TEXT NOT NULL,
 device_name TEXT DEFAULT '', first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
 UNIQUE(license_id, device_id), FOREIGN KEY(license_id) REFERENCES licenses(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS events(
 id INTEGER PRIMARY KEY, license_id INTEGER, kind TEXT NOT NULL, detail TEXT DEFAULT '', at TEXT NOT NULL
);
`);
const adminName = process.env.ADMIN_USERNAME || "admin";
const adminPass = process.env.ADMIN_PASSWORD || "ChangeMe!2026";
if (!db.prepare("SELECT id FROM admins WHERE username=?").get(adminName)) {
  db.prepare("INSERT INTO admins(username,password_hash) VALUES(?,?)").run(adminName, bcrypt.hashSync(adminPass, 12));
}
const now = () => new Date().toISOString();
const hashKey = k => crypto.createHash("sha256").update(String(k)).digest("hex");
const makeKey = () => "SHG-" + crypto.randomBytes(3).toString("hex").toUpperCase() + "-" + crypto.randomBytes(3).toString("hex").toUpperCase() + "-" + crypto.randomBytes(3).toString("hex").toUpperCase();
function event(licenseId, kind, detail="") {
  db.prepare("INSERT INTO events(license_id,kind,detail,at) VALUES(?,?,?,?)").run(licenseId || null, kind, detail, now());
}
function adminAuth(req,res,next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i,"");
  try { req.admin = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({error:"Admin authentication required"}); }
}
function getLicense(key) {
  return db.prepare("SELECT * FROM licenses WHERE key_hash=?").get(hashKey(key || ""));
}
function statusOf(lic) {
  if (!lic) return "not_found";
  if (lic.banned) return "banned";
  if (new Date(lic.expires_at).getTime() <= Date.now()) return "expired";
  return "active";
}
app.get("/api/health", (req,res)=>res.json({ok:true,service:"Shinigami Control API"}));

app.post("/api/admin/login", (req,res)=>{
  const {username,password} = req.body || {};
  const row = db.prepare("SELECT * FROM admins WHERE username=?").get(username);
  if (!row || !bcrypt.compareSync(password || "", row.password_hash)) return res.status(401).json({error:"Invalid username or password"});
  res.json({token:jwt.sign({id:row.id,username:row.username},JWT_SECRET,{expiresIn:"8h"}),username:row.username});
});
app.get("/api/admin/stats", adminAuth, (req,res)=>{
  const total = db.prepare("SELECT COUNT(*) n FROM licenses").get().n;
  const banned = db.prepare("SELECT COUNT(*) n FROM licenses WHERE banned=1").get().n;
  const expired = db.prepare("SELECT COUNT(*) n FROM licenses WHERE banned=0 AND expires_at<=?").get(now()).n;
  const active = total - banned - expired;
  const devices = db.prepare("SELECT COUNT(*) n FROM devices").get().n;
  res.json({total,active,expired,banned,devices});
});
app.get("/api/admin/licenses", adminAuth, (req,res)=>{
  res.json(db.prepare(`SELECT l.id,l.key_hint,l.created_at,l.expires_at,l.banned,l.device_limit,l.note,
    (SELECT COUNT(*) FROM devices d WHERE d.license_id=l.id) device_count,
    (SELECT MAX(last_seen) FROM devices d WHERE d.license_id=l.id) last_seen
    FROM licenses l ORDER BY l.id DESC`).all());
});
app.post("/api/admin/licenses", adminAuth, (req,res)=>{
  const days = Math.max(1,Math.min(3650,Number(req.body.days)||30));
  const deviceLimit = Math.max(1,Math.min(10,Number(req.body.deviceLimit)||1));
  const key = makeKey(), created = now(), expires = new Date(Date.now()+days*86400000).toISOString();
  const info = db.prepare("INSERT INTO licenses(key_hash,key_hint,created_at,expires_at,device_limit,note) VALUES(?,?,?,?,?,?)")
    .run(hashKey(key),key.slice(-4),created,expires,deviceLimit,String(req.body.note||"").slice(0,120));
  event(info.lastInsertRowid,"created",`License created for ${days} days`);
  res.json({id:info.lastInsertRowid,key,expires_at:expires});
});
app.patch("/api/admin/licenses/:id", adminAuth, (req,res)=>{
  const id = Number(req.params.id), lic = db.prepare("SELECT * FROM licenses WHERE id=?").get(id);
  if (!lic) return res.status(404).json({error:"License not found"});
  if (typeof req.body.banned === "boolean") db.prepare("UPDATE licenses SET banned=? WHERE id=?").run(req.body.banned?1:0,id);
  if (Number(req.body.extendDays) > 0) {
    const base = Math.max(Date.now(),new Date(lic.expires_at).getTime());
    const exp = new Date(base+Math.min(3650,Number(req.body.extendDays))*86400000).toISOString();
    db.prepare("UPDATE licenses SET expires_at=? WHERE id=?").run(exp,id);
  }
  event(id,"updated","License updated by admin");
  res.json({ok:true});
});
app.delete("/api/admin/licenses/:id", adminAuth, (req,res)=>{
  const id=Number(req.params.id);
  db.prepare("DELETE FROM devices WHERE license_id=?").run(id);
  db.prepare("DELETE FROM licenses WHERE id=?").run(id);
  event(null,"deleted",`License ${id} deleted`);
  res.json({ok:true});
});
app.get("/api/admin/events", adminAuth, (req,res)=>{
  res.json(db.prepare("SELECT e.*,l.key_hint FROM events e LEFT JOIN licenses l ON e.license_id=l.id ORDER BY e.id DESC LIMIT 100").all());
});

app.post("/api/license/activate", (req,res)=>{
  const {key,deviceId,deviceName=""}=req.body||{};
  if (!key || !deviceId || String(deviceId).length>128) return res.status(400).json({error:"Key and device ID are required"});
  const lic=getLicense(key), status=statusOf(lic);
  if (status!=="active") { event(lic?.id,"activation_denied",status); return res.status(403).json({status,error:`License ${status}`}); }
  const existing=db.prepare("SELECT id FROM devices WHERE license_id=? AND device_id=?").get(lic.id,deviceId);
  const count=db.prepare("SELECT COUNT(*) n FROM devices WHERE license_id=?").get(lic.id).n;
  if (!existing && count>=lic.device_limit) return res.status(403).json({status:"device_limit",error:"Device limit reached"});
  db.prepare(`INSERT INTO devices(license_id,device_id,device_name,first_seen,last_seen) VALUES(?,?,?,?,?)
    ON CONFLICT(license_id,device_id) DO UPDATE SET device_name=excluded.device_name,last_seen=excluded.last_seen`)
    .run(lic.id,deviceId,String(deviceName).slice(0,100),now(),now());
  event(lic.id,"activated",String(deviceName).slice(0,100));
  res.json({status:"active",expires_at:lic.expires_at});
});
app.post("/api/license/check", (req,res)=>{
  const {key,deviceId}=req.body||{}, lic=getLicense(key), status=statusOf(lic);
  if (status!=="active") return res.status(403).json({status,error:`License ${status}`});
  const device=db.prepare("SELECT id FROM devices WHERE license_id=? AND device_id=?").get(lic.id,deviceId);
  if (!device) return res.status(403).json({status:"not_activated",error:"Device is not activated"});
  db.prepare("UPDATE devices SET last_seen=? WHERE license_id=? AND device_id=?").run(now(),lic.id,deviceId);
  res.json({status:"active",expires_at:lic.expires_at});
});
app.listen(PORT,()=>console.log(`Shinigami Control running on ${PORT}`));
