SHINIGAMI CONTROL — Firebase Realtime Database starter
Project ID: shinigami-aa0d8

IMPORTANT
- These are starter rules. They do not create the Realtime Database or deploy rules.
- Create the database in Firebase Console, then paste/import database.rules.json in Realtime Database > Rules.
- Choose the database region carefully; it cannot be changed after creation.
- Enable Firebase Authentication (Email/Password or another supported sign-in method) before testing authenticated access.
- Admin access requires a trusted server environment (for example, Cloud Functions or your own backend using Firebase Admin SDK) to set the custom claim:
    admin: true
  Never put a service-account private key in the Android app or Admin Panel browser code.
- Do not let clients write their own admin/custom-claim status. Custom claims can only be set by a trusted Admin SDK environment.
- The sample rules deny all unspecified paths. Add narrowly scoped rules only when the app's actual data schema is known.
- The sample /users/$uid rule expects a createdAt child when writing a non-empty user record. Adjust validation to match the app's real schema before production.

Suggested initial values (create manually in the Data tab after rules are deployed):
{
  "appConfig": {
    "appEnabled": true,
    "maintenanceMode": false
  },
  "gameControl": {
    "carromEnabled": true
  }
}

Console steps
1. Open https://console.firebase.google.com/
2. Select project shinigami-aa0d8.
3. Build > Realtime Database > Create Database.
4. Select a region and start in locked mode.
5. Open the Rules tab and import/paste database.rules.json, then Publish.
6. Build > Authentication > Get started; enable a sign-in provider.
7. Set the admin custom claim only from a trusted server using Firebase Admin SDK.
8. Add the initial values above in the Data tab.

Security note
The Android app must authenticate users before accessing protected data. Never ship service-account credentials in an APK. Client API keys in google-services.json identify the Firebase project; they are not admin credentials.
